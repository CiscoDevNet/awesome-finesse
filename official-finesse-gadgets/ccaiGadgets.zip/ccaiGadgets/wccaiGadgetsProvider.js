/* eslint-disable max-len */
const FINESSE_AUTH_TOKEN = 'wccai.authToken';
const U2C_HOST = 'wccai.u2chost';
const ORG_ID = 'wccai.orgId';
const CLOUD_CONNECT_MANAGEMENT_CONFIG_URL = '/finesse/api/CloudConnectMgmtService/Config';
const CLOUD_CONNECT_TOKEN_SERVICE_URL = '/finesse/api/CloudConnectTokenService?scopes=cjp-ccai:read,cjp-ccai:write,Identity:SCIM,Identity:Organization,Identity:Config';
const CATALOG_URL = '/u2c/api/v1/user/catalog?types=WCC&services=wccai-serving-api,wccai-data-collector';
const AUTH_TOKEN_REFRESH_TIME = 900000; // 15 Minutes, ie 900000 milliseconds
const SERVING_API_SERVICE_NAME = 'wccai-serving-api';
const FEEDBACK_API_SERVICE_NAME = 'wccai-data-collector';
const DEFAULT_ENVIRONMENT = 'produs1';
const DEV_ENVIRONMENT = 'devus1';
const QA_ENVIRONMENT = 'qaus1';
const INTEG_ENVIRONMENT = 'intgus1';
const APPSTAGING_ENVIRONMENT = 'appstaging';

function fetchAuthToken () {
    const options = {
        headers: {
            'Authorization': window.finesse.utilities.Utilities.getAuthHeaderString(window.finesse.gadget.Config)
        }
    };

    return fetch(encodeURI(CLOUD_CONNECT_TOKEN_SERVICE_URL), options).then(
        (result) => {
            if (result.status === 200) {
                return result.json();
            } else {
                throw Error(`Failed to fetch Token. Reason - ${result.statusText}`);
            }
        }
    ).then(
        (data) => {
            let dataAccessToken = data.access_token;
            // encode if not null
            dataAccessToken = dataAccessToken && encodeURI(dataAccessToken);
            sessionStorage.setItem(FINESSE_AUTH_TOKEN, data.access_token);
            const refreshTime = data.expires_at - new Date().getTime() -
                AUTH_TOKEN_REFRESH_TIME;
            watchAuthTokenExpiry(refreshTime);
            return dataAccessToken;
        }
    );
}

/**
 * @param {Number} refreshTime - Number of ms after which token should be refreshed
 */
function watchAuthTokenExpiry (refreshTime) {
    setTimeout(fetchAuthToken, refreshTime);
}

function removeAuthToken () {
    sessionStorage.removeItem(FINESSE_AUTH_TOKEN);
}

/** Remove authToken from sessionStorage on Refresh/reload. This is required, because on
 * reload, the timer to refresh authToken will be lost. So clearing will setup a new timer.
 */
window.addEventListener('beforeunload', removeAuthToken);

function getCloudConnectMgmtConfig () {
    let u2cHost = sessionStorage.getItem(U2C_HOST);
    let orgId = sessionStorage.getItem(ORG_ID);

    // encode when its not null
    u2cHost = u2cHost && encodeURI(u2cHost);
    orgId = orgId && encodeURI(orgId);

    if (!orgId || !u2cHost) {
        return fetchCloudConnectMgmtConfig();
    } else {
        return Promise.resolve({
            u2cHost: u2cHost,
            orgId: orgId
        });
    }
}

/**
 * This method makes API request to fetch cloud connect Management Config details and
 * stores u2cHost and ordId in session storage
 * Returns {Promise}
 */
function fetchCloudConnectMgmtConfig () {
    const config = window.finesse.gadget.Config;
    const options = {
        headers: {
            'Authorization': window.finesse.utilities.Utilities.getAuthHeaderString(config)
        }
    };
    return fetch(encodeURI(CLOUD_CONNECT_MANAGEMENT_CONFIG_URL), options).then(
        (result) => {
            if (result.status === 200) {
                return result.json();
            } else {
                throw Error(`Failed to fetch Cloud Connect config. Reason-${result.statusText}`);
            }
        }
    ).then(
        (data) => {
            sessionStorage.setItem(U2C_HOST, data.u2cHost);
            sessionStorage.setItem(ORG_ID, data.orgId);
            return data;
        }
    );
}

/**
 * This method makes API request to fetch cloud connect AI Urls and
 * stores serving API and feedback API in session storage
 * Returns {Promise}
 */
function getCCAIUrls (u2cHost, accessToken) {
    let servingUrl = sessionStorage.getItem(SERVING_API_SERVICE_NAME);
    let feedbackUrl = sessionStorage.getItem(FEEDBACK_API_SERVICE_NAME);

    servingUrl = servingUrl && encodeURI(servingUrl);
    feedbackUrl = feedbackUrl && encodeURI(feedbackUrl);

    if (servingUrl && feedbackUrl) {
        return Promise.resolve({
            [SERVING_API_SERVICE_NAME]: servingUrl,
            [FEEDBACK_API_SERVICE_NAME]: feedbackUrl
        });
    } else {
        return fetchCCAIUrls(u2cHost, accessToken);
    }
}

function fetchCCAIUrls (u2cHost, accessToken) {
    if (u2cHost && accessToken) {
        const url = `https://${u2cHost}${CATALOG_URL}`;
        const options = {
            headers: {
                'Authorization': `Bearer ${accessToken}`
            }
        };
        return fetch(encodeURI(url), options).then(
            (result) => {
                if (result.status === 200) {
                    return result.json();
                } else {
                    throw Error(`Failed to fetch Serving url - ${result.statusText}`);
                }
            }
        ).then((data) => {
            const ccaiUrls = {};
            data.services.map((service) => {
                let serviceName = service.serviceUrls[0].baseUrl;
                serviceName = serviceName && encodeURI(serviceName);
                sessionStorage.setItem(service.serviceName, serviceName);
                ccaiUrls[service.serviceName] = serviceName;
            });
            return ccaiUrls;
        });
    } else {
        return Promise.reject(new Error('U2cHostName or accessToken is empty'));
    }
}

/**
 * This method dynamically resolves the environment for Gadget Business logic file.
 * If it encounters error while resolving, it defaults to produs1 environment.
 * Serving API is split with "." and 3rd item from last is considered as environment
 */
async function fetchGadgetCDNEnvironment () {
    loadingIcon.show();
    let environment = DEFAULT_ENVIRONMENT;
    try {
        const token = await fetchAuthToken();
        const configDetails = await getCloudConnectMgmtConfig();
        const ccaiUrls = await getCCAIUrls(configDetails.u2cHost, token);
        environment = calculateEnvironment(ccaiUrls[SERVING_API_SERVICE_NAME]);
    } catch (error) {
        console.log('Gadgets: CcaiGadgets is fetched from default environment as there was a error resolving environment', error);
    }

    var scriptEle = document.createElement('script');
    scriptEle.onload = function () {
        loadingIcon.hide();
    };

    scriptEle.src = `https://ccaigadgets.${environment}.ciscoccservice.com/js/ccai-gadgets.min.js`;
    document.head.appendChild(scriptEle);
}

/**
 *
 * @param {String} servingApiUrl
 * @returns {String}
 * Calculates environment based on serving URL and falls back to default environment if
 * criteria does not match
 */
function calculateEnvironment (servingApiUrl) {
    const tempArr = servingApiUrl.split('.');
    let deployedRegion = tempArr[tempArr.length - 3];
    let environment = DEFAULT_ENVIRONMENT;
    if (deployedRegion.indexOf('dev') === 0) {
        environment = DEV_ENVIRONMENT;
    } else if (deployedRegion.indexOf('qa') === 0) {
        environment = QA_ENVIRONMENT;
    } else if (deployedRegion.indexOf('load') === 0) {
        environment = QA_ENVIRONMENT;
    } else if (deployedRegion.indexOf('appstaging') === 0) {
        environment = APPSTAGING_ENVIRONMENT;
    } else if (deployedRegion.indexOf('intg') === 0) {
        environment = INTEG_ENVIRONMENT;
    }

    console.log('Gadgets: CcaiGadgets is fetched from environment ', environment);
    return environment;
}

/**
 * This method takes care of creating a loading icon and displaying on UI.
 * and hiding the loading icon
 */
const loadingIcon = (() => {
    let spinnerParent;
    const show = () => {
        const fragment = document.createDocumentFragment();
        spinnerParent = document.createElement('div');
        if (spinnerParent) {
            spinnerParent.style.width = '100%';
            spinnerParent.style.height = '100vh';
            spinnerParent.style.display = 'flex';
            spinnerParent.style.flexDirection = 'column';
            spinnerParent.style.justifyContent = 'center';
            spinnerParent.style.alignItems = 'center';
            const spinner = `<svg width=40 height=40 viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path fillRule="evenodd" clipRule="evenodd" d="M0 20C0 31.0455 8.95448 40 20 40C31.0455 40 40 31.0455 40 20C40 8.95448 31.0455 0 20 0C8.95448 0 0 8.95448 0 20ZM39 20C39 30.4932 30.4932 39 20 39C9.50677 39 1 30.4932 1 20C1 9.50677 9.50677 1 20 1C30.4932 1 39 9.50677 39 20Z" fill="#DEDEDE" />
            <mask id="mask0" mask-type="alpha" maskUnits="userSpaceOnUse" x="20" y="0" width="20" height="20">
                <path fillRule="evenodd" clipRule="evenodd" d="M20 0H40V20H20V0Z" fill="white" />
            </mask>
            <g mask="url(#mask0)">
                <path fillRule="evenodd" clipRule="evenodd"
                d="M0 20C0 31.0455 8.95448 40 20 40C31.0455 40 40 31.0455 40 20C40 8.95448 31.0455 0 20 0C8.95448 0 0 8.95448 0 20ZM39 20C39 30.4932 30.4932 39 20 39C9.50677 39 1 30.4932 1 20C1 9.50677 9.50677 1 20 1C30.4932 1 39 9.50677 39 20Z" fill="#121212" />
            </g>
            <animateTransform attributeName="transform" type="rotate" from="0 0 0"
            to="360 0 0" dur="1s" repeatDur="indefinite" />
        </svg>`;
            spinnerParent.insertAdjacentHTML('afterbegin', spinner);
            fragment.appendChild(spinnerParent);
            document.addEventListener('DOMContentLoaded', () => {
                const loadingDiv = document.getElementById('loadingIcon');
                loadingDiv && loadingDiv.appendChild(fragment);
            });
        }
    };

    const hide = () => {
        if (spinnerParent) {
            spinnerParent.style.display = 'none';
        }
    };
    return {
        show: show,
        hide: hide
    };
})();

fetchGadgetCDNEnvironment();

module.exports = {
    fetchAuthToken,
    watchAuthTokenExpiry,
    removeAuthToken,
    calculateEnvironment,
    getCCAIUrls,
    getCloudConnectMgmtConfig,
    fetchCloudConnectMgmtConfig,
    fetchGadgetCDNEnvironment,
    loadingIcon
};
